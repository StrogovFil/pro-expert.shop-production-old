<?
$MESS["SALE_PROPERTIES_RECALCULATE_BASKET"] = "SKU properties affecting cart refresh";
$MESS["CP_SBB_TPL_THEME_SITE"] = "Use site theme (for bitrix.eshop)";
$MESS["CP_SBB_TPL_THEME_BLUE"] = "blue (default theme)";
$MESS["CP_SBB_TPL_THEME_GREEN"] = "green";
$MESS["CP_SBB_TPL_THEME_RED"] = "red";
$MESS["CP_SBB_TPL_THEME_WOOD"] = "wood";
$MESS["CP_SBB_TPL_THEME_YELLOW"] = "yellow";
$MESS["CP_SBB_TPL_THEME_BLACK"] = "dark";
$MESS["CP_SBB_TPL_TEMPLATE_THEME"] = "Color theme";
$MESS["CP_SBB_TPL_USE_ENHANCED_ECOMMERCE"] = "Submit e-commerce data to Google";
$MESS["USE_ENHANCED_ECOMMERCE_TIP"] = "This requires Google Analytics Enhanced Ecommerce options to be configured";
$MESS["CP_SBB_TPL_DATA_LAYER_NAME"] = "Data container name";
$MESS["CP_SBB_TPL_BRAND_PROPERTY"] = "Brand property";
?>